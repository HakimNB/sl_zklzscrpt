-- ========== amc_game ========== 
use `amc_game`; 
 

-- Table : tbl_player_map_building_data
-- Type  : alter
-- RealtionTables : 
-- SQL   : 
ALTER TABLE `tbl_player_map_building_data`
CHANGE `selected_skin_id` `selected_skin_id` int(11) NOT NULL DEFAULT '0',
CHANGE `building_state` `building_state` tinyint(3) unsigned NOT NULL DEFAULT '0' AFTER `selected_skin_id`;

-- Table : tbl_player_map_region_data
-- Type  : alter
-- RealtionTables : 
-- SQL   : 
ALTER TABLE `tbl_player_map_region_data`
CHANGE `region_state` `region_state` tinyint(3) unsigned NOT NULL DEFAULT '0';



-- Table : tbl_player_map_skin_data
-- Type  : alter
-- RealtionTables : 
-- SQL   : 
ALTER TABLE `tbl_player_map_skin_data`
CHANGE `skin_state` `skin_state` tinyint(3) unsigned NOT NULL DEFAULT '0';



-- ========== amc_social ========== 
use `amc_social`; 
 
-- ========== amc_operation ========== 
use `amc_operation`; 
 
-- ========== amc_log ========== 
use `amc_log`; 
 
