-- ========== amc_game ========== 
use `amc_game`; 
 
-- ========== amc_social ========== 
use `amc_social`; 
 
-- ========== amc_operation ========== 
use `amc_operation`; 
 
-- ========== amc_log ========== 
use `amc_log`; 
 
