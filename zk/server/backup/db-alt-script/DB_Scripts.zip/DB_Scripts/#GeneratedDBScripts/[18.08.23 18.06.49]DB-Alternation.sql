-- ========== amc_game ========== 
use `amc_game`; 
 
-- ========== amc_social ========== 
use `amc_social`; 
 
-- Table : tbl_search_player_data
-- Type  : create
-- RealtionTables : 
-- SQL   : 
CREATE TABLE `tbl_search_player_data` (
  `seq` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `iggid` bigint(20) NOT NULL,
  `hex_name` varchar(50) NOT NULL DEFAULT '',
  `accept_friend_flag` tinyint(4) NOT NULL DEFAULT '0',
  `is_online` tinyint(4) NOT NULL DEFAULT '0',
  `last_login_time` bigint(20) NOT NULL DEFAULT '0',
  `main_stage_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`seq`),
  UNIQUE KEY `iggid` (`iggid`),
  KEY `hex_name` (`hex_name`),
  KEY `friend` (`is_online`,`main_stage_id`,`last_login_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Table : tbl_social_posted_message_data
-- Type  : create
-- RealtionTables : 
-- SQL   : 
CREATE TABLE `tbl_social_posted_message_data` (
  `poster_iggid` bigint(20) NOT NULL,
  `post_id` int(10) unsigned NOT NULL,
  `msg_index` tinyint(3) unsigned NOT NULL,
  `iggid` bigint(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `last_update_time` bigint(20) NOT NULL,
  `message` varchar(300) NOT NULL,
  PRIMARY KEY (`poster_iggid`,`post_id`,`msg_index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE tbl_player_name_data;

-- ========== amc_operation ========== 
use `amc_operation`; 
 
-- ========== amc_log ========== 
use `amc_log`; 
 
