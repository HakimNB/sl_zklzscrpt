-- ========== amc_game ========== 
use `amc_game`; 
 

-- Table : tbl_player_map_building_data
-- Type  : create
-- RealtionTables : 
-- SQL   : 
CREATE TABLE `tbl_player_map_building_data` (
  `iggid` bigint(20) NOT NULL,
  `region_id` int(11) NOT NULL,
  `building_id` int(11) NOT NULL,
  `building_state` int(11) DEFAULT NULL,
  `selected_skin_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`iggid`,`region_id`,`building_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- Table : tbl_player_map_region_data
-- Type  : create
-- RealtionTables : 
-- SQL   : 
CREATE TABLE `tbl_player_map_region_data` (
  `iggid` bigint(20) NOT NULL,
  `region_id` int(11) NOT NULL,
  `region_state` int(11) DEFAULT NULL,
  PRIMARY KEY (`iggid`,`region_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- Table : tbl_player_map_skin_data
-- Type  : create
-- RealtionTables : 
-- SQL   : 
CREATE TABLE `tbl_player_map_skin_data` (
  `iggid` bigint(20) NOT NULL,
  `region_id` int(11) NOT NULL,
  `building_id` int(11) NOT NULL,
  `skin_id` int(11) NOT NULL,
  `skin_state` int(11) DEFAULT NULL,
  PRIMARY KEY (`iggid`,`region_id`,`building_id`,`skin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


